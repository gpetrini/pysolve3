""" Test directory.

    Copyright (c) 2014 Kenn Takara
    See LICENSE for details

"""
